package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.AndroidException;
import android.util.AndroidRuntimeException;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {
    CheckBox checkBox;
    EditText user_name;
    EditText subject;
    EditText password;
    Button button;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        subject = findViewById(R.id.ed_subj);
        password = findViewById(R.id.password);
        user_name = findViewById(R.id.edtxt_username);
        /* enable or unable the username */
        checkBox = findViewById(R.id.cd_username_enable);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.getId() == checkBox.getId()) {
                    user_name.setEnabled(b);
                }
            }
        });
        /* Add a password */
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str_subject = subject.getText().toString().trim();
                String str_username = user_name.getText().toString().trim();
                String str_password = password.getText().toString().trim();

                if (str_subject.isEmpty()) {
                    Toast.makeText(AddActivity.this, "You forgot to enter the subject", Toast.LENGTH_SHORT).show();
                } else if (checkBox.isChecked() && str_username.isEmpty()) {
                    Toast.makeText(AddActivity.this, "Enter the username\n\t\tor check it off", Toast.LENGTH_SHORT).show();
                } else if (str_password.isEmpty()) {
                    Toast.makeText(AddActivity.this, "You forgot to enter the password", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent();
                    intent.putExtra("subject", str_subject);
                    if (checkBox.isChecked())
                        intent.putExtra("username", str_username);
                    intent.putExtra("password", str_password);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }
}