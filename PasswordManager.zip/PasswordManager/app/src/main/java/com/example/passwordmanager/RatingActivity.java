package com.example.passwordmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class RatingActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView aspni;
    ImageView visit_card;
    MediaPlayer mediaPlayer;
    ImageView silentOff;
    ImageView silentOn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        /*animation*/
        aspni = findViewById(R.id.aspni);
        visit_card = findViewById(R.id.visit_card);
        visit_card.setAlpha(0f);
        aspni.setScaleX(0f);
        aspni.setScaleY(0f);
        aspni.animate().rotation(360f).setDuration(2000);
        aspni.animate().scaleY(1f).scaleX(1f).setDuration(2000);
        aspni.setOnClickListener(this);
        visit_card.setOnClickListener(this);

        /*voice*/
        silentOff=findViewById(R.id.silent_off);
        silentOff.setOnClickListener(this);
        silentOn=findViewById(R.id.silent);
        silentOn.setOnClickListener(this);
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (aspni.getAlpha() == 1f) {
                    aspni.animate().rotationXBy(180).rotationYBy(180).alpha(0f).setDuration(2000);
                    visit_card.animate().rotationXBy(180).rotationYBy(180).alpha(1f).setDuration(2000);
                } else {
                    aspni.animate().rotationXBy(180).rotationYBy(180).alpha(1f).setDuration(2000);
                    visit_card.animate().rotationXBy(180).rotationYBy(180).alpha(0f).setDuration(2000);
                }
            }
        },6000,6000);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.silent:
            case R.id.silent_off:
                if(silentOff.getVisibility()==View.VISIBLE){
                    silentOff.setVisibility(View.INVISIBLE);
                    mediaPlayer.pause();
                }else {
                    silentOff.setVisibility(View.VISIBLE);
                    mediaPlayer.start();
                }
                break;
            case R.id.aspni:
            case R.id.visit_card:
                Intent intent2 = new Intent(Intent.ACTION_VIEW);
                intent2.setData(Uri.parse("http://www.aspni.ir"));
                startActivity(intent2);
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        /*create media*/
        mediaPlayer = MediaPlayer.create(this, R.raw.backgroundmusic);
        mediaPlayer.start();
        silentOff.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mediaPlayer.stop();
    }
}
